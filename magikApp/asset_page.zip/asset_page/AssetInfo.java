package com.kaltura.magikapp.magikapp.asset_page;

/**
 * Created by zivilan on 02/01/2017.
 */

public class AssetInfo {
}
